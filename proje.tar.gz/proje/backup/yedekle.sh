#!/bin/bash
YEDEK_DIZIN="/home/gazi/proje/backup"
TARIH=$(date +%Y%m%d_%H%M%S)
DOSYA_ADI="db_yedek_$TARIH.sql.gz"

# yedek alma (turkce karakter yok)
docker exec bmt408_db pg_dump -U kullanici proje_vt | gzip > $YEDEK_DIZIN/$DOSYA_ADI

# 7 gunden eski dosyalari silme
find $YEDEK_DIZIN -name "*.sql.gz" -type f -mtime +7 -exec rm {} \;
