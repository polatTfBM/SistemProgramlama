from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
import datetime

# veritabani baglantisi
veritabani_adresi = "postgresql://kullanici:sifre123@db:5432/proje_vt"
motor = create_engine(veritabani_adresi)
Oturum_Uretici = sessionmaker(autocommit=False, autoflush=False, bind=motor)
Taban = declarative_base()

# veritabani tablosu (ORM)
class Oge_Model(Taban):
    __tablename__ = "ogeler"
    id = Column(Integer, primary_key=True, index=True)
    baslik = Column(String, index=True)
    icerik = Column(String)
    kayit_tarihi = Column(DateTime, default=datetime.datetime.utcnow)

Taban.metadata.create_all(bind=motor)

uygulama = FastAPI(title="BMT-408 Proje API")

# veri dogrulama modeli
class Oge_Istek(BaseModel):
    baslik: str
    icerik: str

def veritabani_getir():
    oturum = Oturum_Uretici()
    try:
        yield oturum
    finally:
        oturum.close()

@uygulama.get("/health")
def saglik_kontrolu():
    return {"durum": "tamam"}

@uygulama.post("/items")
def kayit_ekle(oge: Oge_Istek, db: Session = Depends(veritabani_getir)):
    yeni_kayit = Oge_Model(baslik=oge.baslik, icerik=oge.icerik)
    db.add(yeni_kayit)
    db.commit()
    db.refresh(yeni_kayit)
    return yeni_kayit

@uygulama.get("/items")
def kayitlari_getir(db: Session = Depends(veritabani_getir)):
    kayitlar = db.query(Oge_Model).all()
    return kayitlar

@uygulama.get("/items/{kayit_id}")
def tek_kayit_getir(kayit_id: int, db: Session = Depends(veritabani_getir)):
    kayit = db.query(Oge_Model).filter(Oge_Model.id == kayit_id).first()
    if kayit is None:
        raise HTTPException(status_code=404, detail="Kayit bulunamadi")
    return kayit

@uygulama.delete("/items/{kayit_id}")
def kayit_sil(kayit_id: int, db: Session = Depends(veritabani_getir)):
    kayit = db.query(Oge_Model).filter(Oge_Model.id == kayit_id).first()
    if kayit is None:
        raise HTTPException(status_code=404, detail="Kayit bulunamadi")
    db.delete(kayit)
    db.commit()
    return {"mesaj": "Kayit basariyla silindi"}
